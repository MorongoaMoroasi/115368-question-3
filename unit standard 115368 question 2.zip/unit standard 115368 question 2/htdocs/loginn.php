<?php
include("loginserver.php");
include("errors.php");
include("registerserver.php");
?>
<!-- Error Meassage -->
<span style="color: red"><?php echo $errorrr; ?></span>
<!doctype html>
<html>
<html>
<link href='style.css' rel='stylesheet'>
</script>
</html>
<head>
<meta charset="UTF-8">
<title>Login</title>
<style>
.login{	
	max-width:360px;
	min-width:40px;
width:360px;
margin:58px auto;
font:Cambria,"Hoefler Text","Liberation Serif",Times,"Times New Roman",serif;
border-radius:10px;
border:2px solid #ccc;
padding:10px 40px 25px;
margin-top:70px;
}
input[type=text],input[type=password]{
width:99%;
padding:19px;
margin-top:80x;
broder:1pa solid #ccc;
padding-left:5px;
font-size:16px;
font-family:cambria,"Hoefler text","Liberation Serif",Times,"Times new Roman",Serif;
}
input[type=submit]{
width:100%;
background-color:#27ae60;
color:#fff;
border:2px solid #27ae60;
padding:18px;
font-size:28px;
cursor:pointer;
border-radius:5px;
margin-bottom:15px;
}
input[type=button]{
width:100%;
background-color:#009;
color:#fff;
border:2px solid #009;
padding:18px;
font-size:28px;
cursor:pointer;
border-radius:5px;
margin-bottom:15px;
}
</style>

</head>
<body background="L.JPG" document.body.style.backgroundRepeat="repeat-y">
<div style="background-color:white" class="login">
<h1 align="center" style="color: blue">ROOM ALLOCATION SYSTEM</h1>
<script type="text/javascript">
<!-->
var image1=new Image()
image1.src="IMG_20180715_000613.jpg"
var image2=new Image()
image2.src="IMG_20180715_000634.jpg"
var image3=new Image()
image3.src="IMG_20180715_000656.jpg"
var image4=new Image()
image4.src="IMG_20180715_001400.jpg"
var image5=new Image()
image5.src="MBC.jpg"
var image6=new Image()
image6.src="MBB.jpg"
var image7=new Image()
image7.src="MBK.jpg"
var image8=new Image()
image8.src="VK.jpg"
var image9=new Image()
image9.src="VJ.jpg"
var image10=new Image()
image10.src="VN.jpg"
var image11=new Image()
image11.src="VL.jpg"
//-->
</script>
</head>
<body >
<script>
function numbersonly(input){
	var regex =/[^0-9]/g;
	input.value=input.value.replace(regex,"");
}
</script>
<img src="IMG_20180715_000613.jpg" name="slide" width="350" height="150">
<script type="text/javascript">
<!--
var step=1
function slideit(){
	document.images.slide.src=eval("image"+step+".src")
	if(step<11)
		step++
	else
		step=1
	setTimeout("slideit()",2500)
}
slideit()
//-->
</script>
<h1></h1>
<form action="" method="post" style="text-align:center;">
<input type="text" placeholder="USERNAME" id="user" name="user"><br/><br/>
<input type="password" placeholder="PASSWORD" id="pass" name="pass"><br/><br/>
<input type="submit" value="Login" name="login">
<p><a href="registerr.php" style="color: red;">CREATE NEW ACCOUNT</a></p>
<li class="tab"><a href="forget.php">Forget Password?</a></li>
<!-- Error Meassage -->
<span style="color: red"><?php echo $error; ?></span>
</div>

</body>
</html>


