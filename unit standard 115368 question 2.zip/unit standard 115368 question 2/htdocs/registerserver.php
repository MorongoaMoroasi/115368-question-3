<?php
$username="";
$error="";
$errors=array();
$db=mysqli_connect('localhost','root','','userlogin');
if(isset($_POST['register'])){
$username=mysqli_real_escape_string($db,$_POST['user']);
$pass1=mysqli_real_escape_string($db,$_POST['pass']);
$pass2=mysqli_real_escape_string($db,$_POST['pass1']);
$email=mysqli_real_escape_string($db,$_POST['email']);
if(empty($username)){
array_push($errors,"Username is required");
}
if(empty($email)){
array_push($errors,"Email is required");
}
if (empty($pass1)){
array_push($errors,"Password required");
}
if($pass1!=$pass2){
	array_push($errors,"The two password do not match");
	
}if(!empty($username)){if(strlen($username)!=9)
{array_push($errors,"invalid UL student number,i.e must consists of 9 digits");}}
if(!empty($pass1)){if(strlen($pass1)<10)
{array_push($errors,"enter atleast 10 charactors for password");}}	
if(!empty($email)){if(filter_var($email,FILTER_VALIDATE_EMAIL)!=TRUE)	
{array_push($errors,"invalid email address");}}
if(count($errors)==0){
	$query="SELECT * FROM userpass WHERE user='$username'";
	$result=mysqli_query($db,$query);
	if(mysqli_num_rows($result)==1)
	{
$error="USERNAME ALREADY EXITS";}
   else{
	   $pass1=md5($pass1);
	$sql="INSERT INTO userpass(user,pass,email)
	VALUES('$username','$pass1','$email')";
	mysqli_query($db,$sql);
	header("Location: success.php");
   exit();}


}
}
if(isset($_POST['back'])){
header("Location: loginn.php");}
?>