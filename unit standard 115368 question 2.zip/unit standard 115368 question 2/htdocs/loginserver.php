<?php
$errorrr="";
include("registerserver.php");
session_start();
$errors=array();
$db=mysqli_connect('localhost','root','','userlogin');
if(isset($_POST['login'])){
	$username=mysqli_real_escape_string($db,$_POST['user']);
	$pass=mysqli_real_escape_string($db,$_POST['pass']);
	if(empty($username)){
array_push($errors,"Username is required");
}
if (empty($pass)){
array_push($errors,"Password required");
}
if(count($errors)==0){
	$pass=md5($pass);
	$query="SELECT * FROM userpass WHERE user='$username' AND pass='$pass'";
	$result=mysqli_query($db,$query);
	if(mysqli_num_rows($result)==1){
		$_SESSION['admin']='MK@UL.AC.ZA';
		if($_POST['user']!='mk@ul.ac.za')
		{$_SESSION['user']=$_POST['user'];}
		$_SESSION['login']='mk@ul.ac.za';
		if($_POST['user']==$_SESSION['login'] || $_POST['user']==$_SESSION['admin'])
		{header("Location: admin.php");}
else {header("Location: home.php");}}
else {$errorrr="INVALID USERNAME OR PASSWORD";}}
	
}

	
	
	
?>